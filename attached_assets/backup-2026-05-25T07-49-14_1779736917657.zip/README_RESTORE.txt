=== SANTO BOT — RESTORE INSTRUCTIONS ===

HOW TO RESTORE THIS BOT IN A NEW REPLIT PROJECT
================================================

1. CREATE A NEW REPLIT
   - Go to replit.com and create a new project (Node.js)
   - Upload the contents of this ZIP into the project root

2. INSTALL DEPENDENCIES
   Run in the Replit shell:
     npm install
   or if using pnpm:
     pnpm install

3. ADD YOUR SECRETS (Replit Secrets tab)
   Required:
     TOKEN              = your Discord bot token
     OWNER_ID           = your Discord user ID

   AI providers (add at least one):
     OPENROUTER_API_KEY = your OpenRouter key (primary AI)
     GROQ_API_KEY       = your Groq key (fallback AI)
     GROQ_API_KEY_1     = additional Groq key (optional)
     GROQ_API_KEY_2     = additional Groq key (optional)
     GROQ_API_KEY_3     = additional Groq key (optional)
     GROQ_API_KEY_4     = additional Groq key (optional)
     GROQ_API_KEY_5     = additional Groq key (optional)
     DEEPSEEK_API_KEY   = DeepSeek key (tertiary AI, optional)

   Database (if using PostgreSQL features):
     DATABASE_URL       = your PostgreSQL connection string

4. START THE BOT
   Run in the shell:
     npx tsx src/index.ts
   or if using the workflow system:
     The workflow is already configured — just press Run.

5. IF HANDING TO AN AI AGENT (e.g. Replit AI)
   Tell it:
   "This is a Discord bot called santo. It uses discord.js v14,
    TypeScript, and has: AI chat replies (OpenRouter + Groq fallback),
    moderation commands, economy system, word game, brain/memory learning,
    anti-nuke, tickets, and a multi-key AI rotation system.
    The main entry point is src/index.ts."

=== CONTENTS OF THIS BACKUP ===
  src/       All TypeScript source files (auto-scanned)
  data/      Moderation data (warns, mutes, flags, etc.)
  memory/    AI brain memory (phrases, patterns, messages)
  configs/   Bot config files
  package.json, tsconfig.json, build.mjs

=== SECURITY NOTE ===
  This backup does NOT contain any API keys or secrets.
  You must re-add all secrets manually (see Step 3 above).
